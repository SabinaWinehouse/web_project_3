# Practicum Coffee Shop

This is the second project of the Web Development program at Practicum by Yandex. It was created using HTML and CSS, based on the design brief.

## Project features

- Semantic HTML5
- Flexbox
- Positioning
- Flat BEM
- A custom form
- CSS animation and transform

## Plan on improving the project

I really liked this project, I find very unstructive and useful.
I, personally, struggeled whith it for more than a week. But! By the end of the project I felt very confident about my skils and understanding.
So I won't lie, as a person who have started a new jorney to a whole nem world of IT, the project was a bit harsh. But because of my level of understanding that I achieved by doing it I wouldn't make any critical changes.
However, I would add to the brief and to description of the project (and I think this should be written on any other projects) more information about how to start the project. By that I mean some simple instructer that proffesional programmists would recommend:
1.Simply stare at the project for 40 minutes minimum
2.Analize it
3.Understand it
4.Begin to see what is the block of whom
5.What similar blocks do you have,
6.Start building it in your head.
And only then begin the coding of the project itself.
That is what helped me to make a huge progress.
